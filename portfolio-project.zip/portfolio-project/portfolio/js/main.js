(function ($) {
    "use strict";

    //mobile-menu
      $('.mob-bar').click(function(){
        $('.navbar').addClass('info-open');
      })

      $('.close-icon').click(function(){
        $('.navbar').removeClass('info-open');
      })

    // brand-active
    $('.portfolio-active').slick({
        dots: false,
        arrows:true,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
          {
            breakpoint: 1050,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              infinite: true,
              dots: true
            }
          },
          {
            breakpoint: 780,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            }
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            }
          }
        ]
      }); 

  

})(jQuery);	    
